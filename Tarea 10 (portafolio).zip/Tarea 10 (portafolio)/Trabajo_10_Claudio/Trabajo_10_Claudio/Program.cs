﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiembrosClase
{
    internal class Program
    {
        static void Main(string[] args)
        {

            // Llamada al método que pide los datos de los tours
            TourVacaciones[] tours = TourVacaciones.PedirDatosTours();

            // Llamada al método que muestra los tours
            TourVacaciones.MostrarTours(tours);

            // Llamada al método que muestra la cantidad de objetos creados
            TourVacaciones.MostrarCantidadObjetos();
            Console.ReadKey();

        }
      

      class TourVacaciones
      {
        private static int contador = 0;

        public int IdTour { get; set; }
        public string Destino { get; set; }
        public double Precio { get; set; }  //forma abreviada de los get y set
        public DateTime FechaSalida { get; set; }
        public DateTime FechaRegreso { get; set; }
        public string Descripcion { get; set; }

        public TourVacaciones(int idTour, string destino, double precio, DateTime fechaSalida, DateTime fechaRegreso, string descripcion)
        {
            IdTour = idTour;
            Destino = destino;
            Precio = precio;
            FechaSalida = fechaSalida;
            FechaRegreso = fechaRegreso; //constructores
            Descripcion = descripcion;

            contador++;  //cada que se genere una instancia de la clase aumenta el contador//
        }

        public TourVacaciones()
        {
            IdTour = 0;
            Destino = " ";
            Precio = 0;
            FechaSalida = DateTime.MinValue;
            FechaRegreso = DateTime.MinValue; // se utiliza cuando inicialmente no se ha indicado una fecha, pero se establecerá una                            
            Descripcion = " ";
            contador++;
        }

        public static int Contador
        {
            get { return contador; }
        }

        public static TourVacaciones[] PedirDatosTours()
        {
            TourVacaciones[] tours = new TourVacaciones[5]; //se crea el objeto de la clase y se le indica la cantidad que tendrá

            for (int i = 0; i < tours.Length; i++)
            {
                Console.WriteLine("Ingrese los datos del tour {0}:", i + 1);

                Console.Write("Id del tour: ");
                int idTour = int.Parse(Console.ReadLine());

                Console.Write("Destino: ");
                string destino = Console.ReadLine();

                Console.Write("Precio: ");
                double precio = double.Parse(Console.ReadLine());

                Console.Write("Fecha de salida (dd/mm/aaaa): ");
                DateTime fechaSalida = DateTime.Parse(Console.ReadLine());

                Console.Write("Fecha de regreso (dd/mm/aaaa): ");
                DateTime fechaRegreso = DateTime.Parse(Console.ReadLine());

                Console.Write("Descripción: ");
                string descripcion = Console.ReadLine();

                tours[i] = new TourVacaciones(idTour, destino, precio, fechaSalida, fechaRegreso, descripcion);
            }

            return tours;
        }

        public static void MostrarTours(TourVacaciones[] tours)
        {
            Console.WriteLine("Datos de los tours:");
            Console.WriteLine("----------------------------------------------------------------------");
            Console.WriteLine("Id\tDestino\tPrecio\tFecha Salida\tFecha Regreso\tDescripción");
            Console.WriteLine("----------------------------------------------------------------------");

            foreach (TourVacaciones tour in tours)
            {
                Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t{5}", tour.IdTour, tour.Destino, tour.Precio.ToString("F2"), tour.FechaSalida.ToString("dd/MM/yyyy"), tour.FechaRegreso.ToString("dd/MM/yyyy"), tour.Descripcion);
            }

            Console.WriteLine("-----------------------------------------------------------------------");
        }

        public static void MostrarCantidadObjetos()
        {
            Console.WriteLine("Cantidad de objetos TourVacaciones creados: {0}", contador);
        }
      }



    }
}








