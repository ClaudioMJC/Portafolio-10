﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabajo_10_Claudio
{
  /*
    class Program
    {
        
        static void Main()
        {

            var vehiculos = new[]
            {
             new { Placa = "ABC123", Tipo = "automóvil", Color = "rojo", Año = 2020, Fabricante = "Toyota", Modelo = "Corolla" },
             new { Placa = "DEF125", Tipo = "SUB 4x2", Color = "azul", Año = 2019, Fabricante = "Ford", Modelo = "Escape" },
             new { Placa = "GHI126", Tipo = "SUB 4x4", Color = "verde", Año = 2021, Fabricante = "Jeep", Modelo = "Wrangler" },
             new { Placa = "JKL127", Tipo = "automóvil", Color = "blanco", Año = 2018, Fabricante = "Honda", Modelo = "Civic" },
             new { Placa = "MNO128", Tipo = "SUB 4x4", Color = "negro", Año = 2022, Fabricante = "Chevrolet", Modelo = "Camaro" },
             new { Placa = "PQR6129", Tipo = "automóvil", Color = "gris", Año = 2020, Fabricante = "Volkswagen", Modelo = "Safari" }
            };

            Console.WriteLine("Placa\tTipo\t\tColor\t\tAño\tFabricante\tModelo");
            Console.WriteLine("-----------------------------------------------");

            foreach (var vehiculo in vehiculos)
            {
                Console.WriteLine($"{vehiculo.Placa}\t{vehiculo.Tipo}\t{vehiculo.Color}\t\t{vehiculo.Año}\t{vehiculo.Fabricante}\t{vehiculo.Modelo}");
            }
        }
    }  
  */
}
